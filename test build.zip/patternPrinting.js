/**program to print pattern 1,3,6,10,15...*/

let a = 0;
for (let i = 0; i < 10; i++) {
  a = a + i + 1
  return a
}