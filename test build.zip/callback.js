function callback() {
  let data = "I am callback function "
  console.log(data);
}
callback()