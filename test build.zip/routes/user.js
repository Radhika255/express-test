const { body, validationResult } = require('express-validator');
const express = require('express');
const userController = require('../controllers/user');
const router = express.Router();

router.post('/save/details',
  // body("email").isEmail().withMessage("Enter Valid Email"),
  // body("phoneNo").isLength({ min: 10, max: 12 }).withMessage("Phone number length should be 10"),
  // body("password").isLength({ min: 8, max: 10 }).withMessage("Password length should be 8 to 10"),
  userController.saveUser
);

module.exports = router;