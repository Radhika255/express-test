const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  name: String,
  phoneNo: Number,
  email: String,
  age: Number,
  gender: {
    type: String,
    enum: ['male', 'female']
  },
  password: String
})

module.exports = mongoose.model('users', UserSchema)