const userModel = require('../models/User');
const { validationResult } = require('express-validator')
const jwt = require("jsonwebtoken");
const bcrypt = require('bcryptjs');
module.exports = {
  saveUser: async (req, res) => {
    try {
      console.log(req.body);
      const errors = validationResult(req);
      console.log(errors);
      if (!errors.isEmpty()) {
        return res.json({
          statusCode: 400,
          errors: errors.array(),
          message: "Invalid Data"
        });
      } else {
        let user = new userModel(req.body);
        user.password = bcrypt.hashSync(req.body.password, 10);
        user = await user.save();
        return res.json({
          statusCode: 200,
          data: user,
          message: "User Data Saved"
        });
      }
    } catch (error) {
      console.log(error);
      res.json({
        statusCode: 500,
        data: error,
        message: "Error"
      })
    }
  },
  login: async (req, res) => {
    try {
      user = await user.findOne({ _id: req.body.userId, password: req.body.password });
      let authToken = jwt.sign({
        data: {
          id: user._id,
          email: user.email,
          mobileNo: user.mobile,
          accountStatus: user.accountStatus
        }
      }, `${constant.jwtSecret}`, { expiresIn: '360days' });
      return res.json({
        statusCode: 200,
        data: user,
        message: "User Data Saved"
      });
    } catch (error) {
      console.log(error);
      res.json({
        statusCode: 500,
        data: error,
        message: "Error"
      })
    }
  }
}